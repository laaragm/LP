<!DOCTYPE html>
<html>
<body>

<?php
	$array = array("lp", "llp", "aeds 2", "laeds 2", "aoc", "laoc");
    echo "Disciplinas: <br>";
	foreach($array as $item) {
	    echo "<li> $item";
	}
?>

</body>
</html>
