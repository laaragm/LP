<?php
	$names = array("Lara", "Fúlvio");
    $sentence = "Dupla de LLP: {$names[0]} e {$names[1]}";
    echo $sentence;
?> 