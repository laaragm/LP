<!DOCTYPE html>
<html>
<body>

<?php
  $name = "Lara";
  $name2 = "Fúlvio";
  echo "Relatório sobre PHP feito por:<br><li>" . $name . "<br><li>" . $name2 . "<br>";
?>

</body>
</html>
