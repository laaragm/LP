<?php
	$array = [
    	"llp" => "91",
    	"lp" => "93",
	];
    echo var_dump($array);
    echo "<br> {$array['llp']}";
?> 