<!DOCTYPE html>
<html>
<body>

<?php
    echo "<h1> Hello World! </h1>";
?>

</body>
</html>
