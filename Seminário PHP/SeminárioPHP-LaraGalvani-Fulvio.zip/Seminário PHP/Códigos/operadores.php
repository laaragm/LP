<?php
	echo "Comparação de valor: ";
	if (false == 0){
    	echo 'true';
    } else {
		echo 'false';
	}
    
    echo "<br>Comparação de valor e tipo: ";
	if (false === 0){
    	echo 'true';
    } else {
		echo 'false';
	}
?> 