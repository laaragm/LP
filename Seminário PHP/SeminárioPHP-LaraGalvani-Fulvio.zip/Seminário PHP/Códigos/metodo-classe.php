<?php
  class TheTestClass
  {
      function hello()
      {
          echo "Testing class function."; 
      }
  }

  $testClassObject = new TheTestClass;
  $testClassObject->hello();
?> 