<!DOCTYPE html>
<html>
<body>

<?php
  $var = "5";
  $var2 = 10;
  echo $var + $var2;
?>

</body>
</html>
