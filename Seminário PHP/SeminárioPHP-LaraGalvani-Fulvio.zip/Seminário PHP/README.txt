Seminário PHP
Dupla: Lara Galvani Moura e Fúlvio Taroni Monteforte

O relatório sobre a linguagem está no arquivo "Seminário PHP - Lara Galvani e Fúlvio.pdf".
O vídeo gravado baseado no relatório apresentando a linguagem pode ser acessado através
do seguinte link (o link também foi incluído no relatório): https://www.youtube.com/watch?v=fbQLylgxlak&feature=youtu.be
Os slides apresentados no vídeo estão no arquivo "Slides seminário PHP.pptx".
Os códigos implementados para servirem de exemplo no relatório estão na pasta "Códigos", mas também podem ser acessados
através do link: https://github.com/laaragm/PHP-Examples