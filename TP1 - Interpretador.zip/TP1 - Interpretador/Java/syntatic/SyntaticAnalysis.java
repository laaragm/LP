package syntatic;

import java.io.IOException;
import java.util.Map;
import java.util.HashMap;

import lexical.Lexeme;
import lexical.TokenType;
import lexical.LexicalAnalysis;
import lexical.LexicalException;
import interpreter.command.ArrayValue;
import interpreter.command.AssignOp;
import interpreter.command.BlocksCommand;
import interpreter.command.Command;
import interpreter.command.CompositeValue;
import interpreter.command.EchoCommand;
import interpreter.command.ForeachCommand;
import interpreter.command.IfCommand;
import interpreter.command.IntegerValue;
import interpreter.command.StringValue;
import interpreter.command.Value;
import interpreter.command.WhileCommand;
import interpreter.expressions.BinaryExpr;
import interpreter.expressions.BinaryOp;
import interpreter.expressions.BoolExpr;
import interpreter.expressions.CompositeBoolExpr;
import interpreter.expressions.Expr;
import interpreter.expressions.RelOp;
import interpreter.expressions.StringExpressionValue;
import interpreter.expressions.Variable;

public class SyntaticAnalysis {

	private HashMap <String, Variable> variables = new HashMap<String, Variable>();
    private LexicalAnalysis lex;
    private Lexeme current;

    public SyntaticAnalysis(LexicalAnalysis lex) throws LexicalException, IOException {
        this.lex = lex;
        this.current = lex.nextToken();
    }

    public Command start() throws LexicalException, IOException {
    	Command command = procCode(); 
        matchToken(TokenType.END_OF_FILE);
        
		return command;  
    }

    private void matchToken(TokenType type) throws LexicalException, IOException {
        System.out.println("Match token: " + current.type + " -> " + type + " (\"" + current.token + "\")");
        if (type == current.type) {
            current = lex.nextToken();
        } else {
            showError();
        }
    }

    private void showError() {
        System.out.printf("%02d: ", lex.getLine());

        switch (current.type) {
            case INVALID_TOKEN:
                System.out.printf("Lexema inv�lido [%s]\n", current.token);
                break;
            case UNEXPECTED_EOF:
            case END_OF_FILE:
                System.out.printf("Fim de arquivo inesperado\n");
                break;
            default:
                System.out.printf("Lexema n�o esperado [%s]\n", current.token);
                break;
        }

        System.exit(1);
    }

    // <code> ::= { <statement> }
    private BlocksCommand procCode() throws LexicalException, IOException {
        Command c;
        // There is no precise way to track the line number for block commands, thus using -1.
        BlocksCommand cb = new BlocksCommand(-1);
        
    	while (current.type == TokenType.IF || current.type == TokenType.WHILE ||
    			current.type == TokenType.FOREACH || current.type == TokenType.ECHO ||
    		    current.type == TokenType.INC || current.type == TokenType.DEC ||
    		    current.type == TokenType.DOLAR || current.type == TokenType.VAR ||
    		    current.type == TokenType.OPEN_PAR)
    	{
    		c = procStatement();
    		cb.addCommand(c);
    	}
    	return cb;
    }

    // <statement> ::= <if> | <while> | <foreach> | <echo> | <assign>
    private Command procStatement() throws LexicalException, IOException {
    	Command c;
		if (current.type == TokenType.IF) {
    		c = procIf();
    	}
    	else if (current.type == TokenType.WHILE) {
    		c = procWhile();
    	}
    	else if (current.type == TokenType.FOREACH) {
    		c = procForeach();
    	}
    	else if (current.type == TokenType.ECHO) {
    		c = procEcho();	
    	}
    	else { // TODO: VAR OU ASSIGN O TOKENTYPE
    		c = procAssign();	
    	}
		
		return c;
    }

    // <if> ::= if '(' <boolexpr> ')' '{' <code> '}'
    //              { elseif '(' <boolexpr> ')' '{' <code> '}' }
    //              [ else '{' <code> '}' ]
    private IfCommand procIf() throws LexicalException, IOException {
    	matchToken(TokenType.IF);
    	int line = lex.getLine();
    	IfCommand ifCommand;
    	matchToken(TokenType.OPEN_PAR);
    	BoolExpr boolExpr = procBoolExpr();
    	matchToken(TokenType.CLOSE_PAR);
    	matchToken(TokenType.OPEN_CUR);
    	Command c = procCode();
    	matchToken(TokenType.CLOSE_CUR);
    	
    	Command thenCmds = null;
    	while (current.type == TokenType.ELSEIF) {
    		matchToken(TokenType.ELSEIF);
        	matchToken(TokenType.OPEN_PAR);
        	BoolExpr boolExprThenCmds = procBoolExpr();
        	matchToken(TokenType.CLOSE_PAR);
        	matchToken(TokenType.OPEN_CUR);
        	thenCmds = procCode();
        	matchToken(TokenType.CLOSE_CUR);
    	}
    	
    	Command elseCmds = null;
    	if (current.type == TokenType.ELSE) {
    		matchToken(TokenType.ELSE);
        	matchToken(TokenType.OPEN_CUR);
        	elseCmds = procCode();
        	matchToken(TokenType.CLOSE_CUR); 
    	}
    	
    	ifCommand = new IfCommand(line, boolExpr, thenCmds);
    	ifCommand.addElseCommands(elseCmds);
    	
		return ifCommand;
    }

    // <while> ::= while '(' <boolexpr> ')' '{' <code> '}'
    private WhileCommand procWhile() throws LexicalException, IOException {   
    	int line = lex.getLine();
    	matchToken(TokenType.WHILE);
    	matchToken(TokenType.OPEN_PAR);
    	BoolExpr cond = procBoolExpr();
    	matchToken(TokenType.CLOSE_PAR);
    	matchToken(TokenType.OPEN_CUR);
    	Command command = procCode();
    	matchToken(TokenType.CLOSE_CUR);
    	WhileCommand whileCommand = new WhileCommand(line, cond, command); 
		return whileCommand;
    }

    // <foreach> ::= foreach '(' <expr> as <var> [ '=>' <var> ] ')' '{' <code> '}'
    private ForeachCommand procForeach() throws LexicalException, IOException {
    	int line = lex.getLine();
    	matchToken(TokenType.FOREACH);
    	matchToken(TokenType.OPEN_PAR);
    	Expr expr = procExpr();
    	matchToken(TokenType.AS);
    	Variable key = procVar();
    	Variable value = null;
    	
    	if (current.type == TokenType.ARROW) {
    		matchToken(TokenType.ARROW);
    		value = procVar();
    	}
    	
    	matchToken(TokenType.CLOSE_PAR);
    	matchToken(TokenType.OPEN_CUR);
    	Command cmds = procCode();    	
    	matchToken(TokenType.CLOSE_CUR);
    	
    	ForeachCommand foreachCommand = new ForeachCommand(line, expr, cmds, key, value);
    	return foreachCommand; //int line, Expr expr, Command cmds, Variable key, Variable value
    }

    // <echo> ::= echo <expr> ';'
    private EchoCommand procEcho() throws LexicalException, IOException { //EchoCommand
    	matchToken(TokenType.ECHO);
    	int line = lex.getLine();
    	Expr procExpr = procExpr(); 
    	matchToken(TokenType.SEMICOLON);
        EchoCommand echoCommand = new EchoCommand(line, procExpr); //int line, Expr expr

    	return echoCommand;
    }

    // <assign> ::= <value> [ ('=' | '+=' | '-=' | '.=' | '*=' | '/=' | '%=') <expr> ] ';'
    private Command procAssign() throws LexicalException, IOException {
    	procValue();
    	
    	if (current.type == TokenType.ASSIGN) {
    		matchToken(TokenType.ASSIGN);
    		procExpr();
    	}
    	else if (current.type == TokenType.ASSIGN_ADD) {
    		matchToken(TokenType.ASSIGN_ADD);
    		procExpr();
    	} 
    	else if (current.type == TokenType.ASSIGN_SUB) {
    		matchToken(TokenType.ASSIGN_SUB);
    		procExpr();
    	} 
    	else if (current.type == TokenType.ASSIGN_CONCAT) {
    		matchToken(TokenType.ASSIGN_CONCAT);
    		procExpr();
    	} 
    	else if (current.type == TokenType.ASSIGN_MUL) {
    		matchToken(TokenType.ASSIGN_MUL);
    		procExpr();
    	} 
    	else if (current.type == TokenType.ASSIGN_DIV) {
    		matchToken(TokenType.ASSIGN_DIV);
    		procExpr();
    	} 
    	else if (current.type == TokenType.ASSIGN_MOD) {
    		matchToken(TokenType.ASSIGN_MOD);
    		procExpr();
    	} 
    	   	
    	matchToken(TokenType.SEMICOLON);
		return null; //int line, Expr left, AssignOp op, Expr right
    }

    // <boolexpr> ::= [ '!' ] <cmpexpr> [ (and | or) <boolexpr> ]
    private BoolExpr procBoolExpr() throws LexicalException, IOException {
    	int line = lex.getLine();
    	if (current.type == TokenType.NOT) {
    		Command c = procCmpExpr();
    		
    		if (current.type == TokenType.AND || current.type == TokenType.OR) {
    			BoolExpr cond = procBoolExpr();
    			return cond;
    		}
    	}
		return null;
    }

    // <cmpexpr> ::= <expr> ('==' | '!=' | '<' | '>' | '<=' | '>=') <expr>
    private Command procCmpExpr() throws LexicalException, IOException {
    	procExpr();
    	
    	if (current.type == TokenType.EQUAL || current.type == TokenType.NOT_EQUAL
    		|| current.type == TokenType.GREATER || current.type == TokenType.LOWER
    		|| current.type == TokenType.GREATER_EQ || current.type == TokenType.LOWER_EQ) {
    		procExpr();
    	}
		return null;
    }

    // <expr> ::= <term> { ('+' | '-' | '.') <term> }
    private Expr procExpr() throws LexicalException, IOException {
    	int line = lex.getLine();
    	Value<?> leftValue = procTerm();
    	BinaryOp op = null;
    	Value<?> rightValue = null;
    	
    	while (current.type == TokenType.ADD || current.type == TokenType.SUB || current.type == TokenType.CONCAT) {
    		if (current.type == TokenType.ADD) {
    			matchToken(TokenType.ADD);
    			op = BinaryOp.AddOp;
    		}
    		else if (current.type == TokenType.SUB) {
    			matchToken(TokenType.SUB);
    			op = BinaryOp.SubOp;
    		}
    		else if (current.type == TokenType.CONCAT) {
    			matchToken(TokenType.CONCAT);
    			op = BinaryOp.ConcatOp;
    		}
    		rightValue = procTerm();
    	}
    	//BinaryExpr binaryExpr = new BinaryExpr(line, leftValue, op, rightValue); //int line, Expr left, BinaryOp op, Expr right
    	
		//return binaryExpr;
    	return null;
    }

    // <term> ::= <factor> { ('*' | '/' | '%') <factor> }
    private Value<?> procTerm() throws LexicalException, IOException {
    	int line = lex.getLine();
        Value<?> left = procFactor();
        BinaryExpr binaryExpr = null;
        Value<?> value = null;
    	
    	while (current.type == TokenType.MUL || current.type == TokenType.DIV || current.type == TokenType.MOD) {
    		BinaryOp op = null;
    		if (current.type == TokenType.MUL) {
    			matchToken(TokenType.MUL);
    			op = BinaryOp.MulOp;
    		}
    		else if (current.type == TokenType.DIV) {
    			op = BinaryOp.DivOp;
    			matchToken(TokenType.DIV);
    		}
    		else if (current.type == TokenType.MOD) {
    			op = BinaryOp.ModOp;
    			matchToken(TokenType.MOD);
    		}
    		value = procFactor();
    		//binaryExpr = new BinaryExpr(line, left, op, value); //int line, Expr left, BinaryOp op, Expr right
    	}
    	return value;
    }

    // <factor> ::= <number> | <string> | <array> | <read> | <value>
    private Value<?> procFactor() throws LexicalException, IOException {
    	Value<?> value = null;
    	if (current.type == TokenType.NUMBER) {
    		value = procNumber();
    	}
    	else if (current.type == TokenType.STRING) {
    		value = procString();
    	} 
    	else if (current.type == TokenType.ARRAY) {
    		value = procArray();
    	}
    	else if (current.type == TokenType.READ) {
    		value = procRead();
    	}
    	else { 
    		value = procValue();
    	}
    	
		return value;   	
    }

    // <array> ::= array '(' [ <expr> '=>' <expr> { ',' <expr> '=>' <expr> } ] ')'
    private Value<?> procArray() throws LexicalException, IOException {
    	Map<String, Value<?>> value = null;
    	matchToken(TokenType.ARRAY);
    	matchToken(TokenType.OPEN_PAR);
    	Expr expr = procExpr();
    	String key = current.token;
    	//value.put(key, expr);
    	
    	matchToken(TokenType.ARROW);
    	expr = procExpr();
    	key = current.token;
    	//value.put(key, expr);
    	
    	while (current.type == TokenType.COMMA) {
    		matchToken(TokenType.COMMA);
    		expr = procExpr();
    		key = current.token;
        	//value.put(key, expr);
    		matchToken(TokenType.ARROW);
    		expr = procExpr();
    		key = current.token;
        	//value.put(key, expr);
    	}
    	
    	matchToken(TokenType.CLOSE_PAR);
    	
    	ArrayValue arrayValue = new ArrayValue(value); //Map<String, Value<?>> value
		return arrayValue;   
    }

    // <read> ::= read <string>
    private Value<?> procRead() throws LexicalException, IOException {
    	matchToken(TokenType.READ);
    	Value<?> value = procString();
    	
    	return value;
    }

    // <value> ::= [ ('++' | '--') ] <access> | <access> [ ('++' | '--') ]
    private Value<?> procValue() throws LexicalException, IOException {
    	Value value = null;
    	if (current.type == TokenType.INC || current.type == TokenType.DEC) {
    		if (current.type == TokenType.INC) {
        		matchToken(TokenType.INC);
        		value = procAccess();
        	}
        	else if (current.type == TokenType.DEC) {
        		matchToken(TokenType.DEC);
        		value = procAccess();
        	}
    	}
    	else {
    		value = procAccess();
    		if (current.type == TokenType.INC) {
        		matchToken(TokenType.INC);
        	}
        	else if (current.type == TokenType.DEC) {
        		matchToken(TokenType.DEC);
        	}
    	}
    	
    	return value;
    }

    // <access> ::= ( <varvar> | '(' <expr> ')' ) [ '[' <expr> ']' ]
    private Value<?> procAccess() throws LexicalException, IOException {
    	if (current.type == TokenType.OPEN_PAR) {
    		matchToken(TokenType.OPEN_PAR);
    		Expr expr = procExpr();
        	matchToken(TokenType.CLOSE_PAR);
    	}
    	else {
    		Variable variable = procVarVar();
    	} 
    	
    	if (current.type == TokenType.OPEN_BRA) {
    		matchToken(TokenType.OPEN_BRA);
    		Expr expr = procExpr();
        	matchToken(TokenType.CLOSE_BRA);
    	}
    	
		return null;
    }

    // <varvar> ::= '$' <varvar> | <var>
    private Variable procVarVar() throws LexicalException, IOException {
    	Variable variable;    
    	if (current.type == TokenType.DOLAR) {
    		matchToken(TokenType.DOLAR);
    		variable = procVarVar();
    	}
    	else { 
    		variable = procVar();
    	}
    	return variable;
    }

    private IntegerValue procNumber() throws LexicalException, IOException {
    	IntegerValue integerValue;
        String text = current.token;
    	matchToken(TokenType.NUMBER);
    	int value = Integer.parseInt(text);
    	integerValue = new IntegerValue(value);
        return integerValue;
    }

    private StringValue procString() throws LexicalException, IOException {   	
        String text = current.token;
        matchToken(TokenType.STRING);  
        StringValue stringValue = new StringValue(text);
        
        return stringValue;
    }

    private Variable procVar() throws LexicalException, IOException {
    	String str = current.token;
    	Variable variable;
    	matchToken(TokenType.VAR);
    	     
    	
        if(variables.containsKey(str)){
            variable = variables.get(str);
        }
        else{
            variable = new Variable(str);
            variables.put(str, variable);
        }
        
        return variable;
    }

}
