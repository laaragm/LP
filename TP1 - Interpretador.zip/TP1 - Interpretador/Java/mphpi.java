import lexical.Lexeme;
import lexical.LexicalAnalysis;
import lexical.TokenType;
import lexical.LexicalException;

import syntatic.SyntaticAnalysis;

import interpreter.command.Command;

public class mphpi {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java mphpi [MiniPHP File]");
            return;
        }

        try (LexicalAnalysis l = new LexicalAnalysis(args[0])) {
    	//String file = "C:\\Users\\larag\\OneDrive\\�rea de Trabalho\\CEFET\\LLP\\TP1 - Interpretador\\examples\\mega.mphp";
        //try (LexicalAnalysis l = new LexicalAnalysis(file)) {
            // O c�digo a seguir ser� usado para testar o interpretador.
            // TODO: descomentar depois que o analisador l�xico estiver OK.
            SyntaticAnalysis s = new SyntaticAnalysis(l);
            Command c = s.start();
            c.execute();

            // O c�digo a seguir ser� usado para testar o analisador l�xico.
            // TODO: depois de pronto, comentar o c�digo abaixo.
            Lexeme lex = l.nextToken();
            //while (checkType(lex.type)) {
                //System.out.printf("(\"%s\", %s)\n", lex.token, lex.type);
                //lex = l.nextToken();
            //}

            switch (lex.type) {
                case INVALID_TOKEN:
                    System.out.printf("%02d: Lexema inv�lido [%s]\n", l.getLine(), lex.token);
                    break;
                case UNEXPECTED_EOF:
                    System.out.printf("%02d: Fim de arquivo inesperado\n", l.getLine());
                    break;
                default:
                    System.out.printf("(\"%s\", %s)\n", lex.token, lex.type);
                    break;
            }
        } catch (Exception e) {
            System.err.println("Internal error: " + e.getMessage());
        }
    }

    private static boolean checkType(TokenType type) {
        return !(type == TokenType.END_OF_FILE ||
                 type == TokenType.INVALID_TOKEN ||
                 type == TokenType.UNEXPECTED_EOF);
    }
}

