package lexical;

//Estrutura que carrega um token e o tipo desse token
//Token � uma string com o elemento formado, e type � o tipo do token
public class Lexeme {
    public String token;
    public TokenType type;

    public Lexeme(String token, TokenType type) {
        this.token = token;
        this.type = type;
    }
}
