package interpreter.expressions;

public class AccessExpr {

	protected Expr base;
	protected Expr index;
	
	public AccessExpr(int line, Expr base, Expr index) {
		this.base = base;
		this.index = index;
	}
	
	public AccessExpr(Expr base, Expr index) {
		this.base = base;
		this.index = index;
	}
	
	public Value<?> expr(){
		return null;
	}
	
	public void setExpr(Value<?> value) {
		
	}
}
