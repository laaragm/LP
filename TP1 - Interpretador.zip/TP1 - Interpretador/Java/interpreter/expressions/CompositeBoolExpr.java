package interpreter.expressions;

public class CompositeBoolExpr extends BoolExpr {
	
	protected RelOp op;
	protected BoolExpr left;
	protected BoolExpr right;
    
	public CompositeBoolExpr(int line, BoolExpr left, RelOp op, BoolExpr right) {
		super(line);
		this.left = left;
		this.op = op;
		this.right = right;
	}
	
	public int getLine() {
		return line;
	}

	@Override
	public boolean expr() {
		return false;
	}
}
