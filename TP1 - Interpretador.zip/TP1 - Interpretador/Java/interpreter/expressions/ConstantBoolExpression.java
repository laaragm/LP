package interpreter.expressions;

public class ConstantBoolExpression extends BoolExpr {
	
	public boolean value;
	
	public ConstantBoolExpression(int line, boolean value) {
		super(line);
		this.value = value;
	}
	
	public boolean expr() {
		return value;
	}
}
