package interpreter.expressions;

public class BinaryIntExpression extends IntegerExpression {
	
	private IntegerExpression left;
	private IntOperations op;
	private IntegerExpression right;
	
	public BinaryIntExpression(int line, IntegerExpression left, IntOperations op, IntegerExpression right) {
		super(line);
		this.left = left;
		this.op = op;
		this.right = right;
	}
	
	public int expr() {
		int firstValue = left.expr();
		int secondValue = right.expr();
		
		switch(op) {
			case Add:
	            return firstValue + secondValue;
	        case Subtract:
	            return firstValue - secondValue;
	        case Multiply:
	            return firstValue * secondValue;
	        case Divide:
	            return firstValue / secondValue;
	        case Module:
	        	return firstValue % secondValue;
	        default:
	            return firstValue % secondValue;
		}
	}
}
