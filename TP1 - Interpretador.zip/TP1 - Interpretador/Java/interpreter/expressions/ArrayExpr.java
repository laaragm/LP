package interpreter.expressions;

import java.util.Map;

public class ArrayExpr extends Expr {

	protected Map<Expr, Expr> array;
	
	public ArrayExpr(int line) {
		super(line);
	}
	
	public void insert(Expr key, Expr value) {
		this.array.put(key, value);
	}

	@Override
	public Value<?> expr() {
		return null;
	}
	
}
