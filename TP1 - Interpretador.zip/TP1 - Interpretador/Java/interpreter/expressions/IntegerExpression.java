package interpreter.expressions;

public abstract class IntegerExpression {
	private int line;

    public IntegerExpression(int line) {
        this.line = line;
    }

    public int getLine() {
        return line;
    }

    public abstract int expr();
}
