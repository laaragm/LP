package interpreter.expressions;

public enum BoolOp {
	And,
	Or
}
