package interpreter.expressions;

public class SetExpr extends Expr {
		
	public SetExpr(int line) {
		super(line);
	}

	@Override
	public Value<?> expr() {
		return null;
	}
	
	public void setExpr(Value<?> value) {
		
	}

	
}
