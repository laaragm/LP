package interpreter.expressions;

public abstract class StringExpressionValue extends Value<String> {

	public StringExpressionValue(int line) {
		super(line);
	}
		
	public abstract String value();
}
