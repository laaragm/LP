package interpreter.expressions;

public abstract class Value<T> { 
	
	private int line;

	public Value(int line) {
        this.line = line;
    }
	
	public void setLine(int line) {
        this.line = line;
    }
	
    public int getLine() {
        return line;
    }
    
    // Retorno gen�rico a ser definido por cada uma das classes que ir�o herdar de Value
    public abstract T value(); 
}
