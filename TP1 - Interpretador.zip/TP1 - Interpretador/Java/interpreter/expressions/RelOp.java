package interpreter.expressions;

public enum RelOp {
	Equal,
	NotEqual,
	LowerThan,
	LowerEqual,
	GreaterThan,
	GreaterEqual
}
