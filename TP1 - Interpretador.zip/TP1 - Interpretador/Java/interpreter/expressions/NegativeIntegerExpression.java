package interpreter.expressions;

public class NegativeIntegerExpression extends IntegerExpression {
	
	private IntegerExpression expr;
	
	public NegativeIntegerExpression(int line, IntegerExpression expr) {
		super(line);
		this.expr = expr;
	}

	public int expr() {
		return -expr.expr();
	}
}
