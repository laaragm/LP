package interpreter.expressions;

public abstract class BoolExpr {
	
	protected int line;
	
	public BoolExpr(int line) {
		this.line = line;
	}
	
	public int getLine() {
		return line;
	}
	
	public abstract boolean expr();
}
