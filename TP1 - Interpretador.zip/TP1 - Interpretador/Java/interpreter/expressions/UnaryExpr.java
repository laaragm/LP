package interpreter.expressions;

public class UnaryExpr extends Expr {

	protected Expr expr;
	protected UnaryOp op; 
	
	public UnaryExpr(int line, Expr expr, UnaryOp op) {
		super(line);
		this.expr = expr;
		this.op = op;
	}

	@Override
	public Value<?> expr() {
		return null;
	}
		
}
