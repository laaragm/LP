package interpreter.expressions;

public enum BinaryOp {
	AddOp,
	SubOp,
	ConcatOp,
	MulOp,
	DivOp,
	ModOp
}
