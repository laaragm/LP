package interpreter.expressions;

public class BinaryExpr extends Expr {

	protected Expr left;
	protected BinaryOp op;
	protected Expr right;
	
	public BinaryExpr(int line, Expr left, BinaryOp op, Expr right) {
		super(line);
		this.left = left;
		this.op = op;
		this.right = right;
	}
	
	@Override
	public Value<?> expr() {
		return null;
	}
	
}
