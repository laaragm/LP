package interpreter.expressions;

public class NotBoolExpr extends BoolExpr {

	protected BoolExpr expr;
	
	public NotBoolExpr(int line, BoolExpr expr) {
		super(line);
		this.expr = expr;
	}
	
	public int getLine() {
		return line;
	}

	@Override
	public boolean expr() {
		return false;
	}

}
