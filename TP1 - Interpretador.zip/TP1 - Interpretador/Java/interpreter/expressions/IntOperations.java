package interpreter.expressions;

public enum IntOperations {
	Add,
	Subtract,
	Multiply,
	Divide,
	Module
}
