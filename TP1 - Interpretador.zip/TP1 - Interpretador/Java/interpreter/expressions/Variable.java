package interpreter.expressions;

import java.util.Map;

public class Variable {

	protected Map<String, Variable> variables;
	protected String name;
	protected Value<?> value;
	
	public Variable(String name) {
		this.name = name;
	}
	
	public Variable instance(String name) {
		return null;
	}
	
	public String getName() {
		return this.name;
	}
	
	public Value<?> expr(){
		return null;
	}
	
	public void setExpr(Value<?> value) {
		this.value = value;
	}
}
