package interpreter.expressions;

public class VarVarExpr extends SetExpr {

	protected Expr varvar;
	
	public VarVarExpr(int line, Expr varvar) {
		super(line);
		this.varvar = varvar;
	}

	public Value<?> expr(){
		return null;
	}
	
	public void setExpr(Value<?> value) {
		
	}
	
}
