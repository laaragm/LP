package interpreter.expressions;

public class ReadExpr extends Expr {

	protected Expr msg;
	
	public ReadExpr(int line, Expr msg) {
		super(line);
		this.msg = msg;
	}

	@Override
	public Value<?> expr() {
		return null;
	}
	
}
