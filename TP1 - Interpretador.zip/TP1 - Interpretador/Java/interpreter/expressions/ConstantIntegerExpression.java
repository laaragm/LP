package interpreter.expressions;

public class ConstantIntegerExpression extends IntegerExpression {
	
	private int value;
	
	public ConstantIntegerExpression(int line, int value) {
		super(line);
		this.value = value; 
	}
	
	public int expr() {
		return value;
	}
}
