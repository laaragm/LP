package interpreter.expressions;

public enum UnaryOp {
	PreIncOp,
	PreDecOp,
	PosIncOp,
	PosDecOp
}
