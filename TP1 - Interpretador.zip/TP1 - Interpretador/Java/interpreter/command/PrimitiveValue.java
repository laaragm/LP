package interpreter.command;

public abstract class PrimitiveValue<T> extends Value<T> {

	protected PrimitiveValue() {
	
	}

	public abstract T value();
	  
}
