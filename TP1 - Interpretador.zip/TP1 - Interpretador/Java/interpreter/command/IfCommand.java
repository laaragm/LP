package interpreter.command;

import interpreter.expressions.BoolExpr;

public class IfCommand extends Command {
	
	protected BoolExpr cond;
	protected Command thenCmds;
	protected Command elseCms;

	public IfCommand(int line, BoolExpr cond, Command thenCmds) {
		super(line);
		this.cond = cond;
		this.thenCmds = thenCmds;
	}
	
	public void addElseCommands(Command elseCmds) {
		this.elseCms = elseCmds;
	}

	@Override
	public void execute() {
		
	}

}
