package interpreter.command;

import interpreter.expressions.Expr;
import interpreter.expressions.Variable;

public class ForeachCommand extends Command{

	protected Expr expr;
	protected Command cmds;
	protected Variable key;
	protected Variable value;
	
	public ForeachCommand(int line, Expr expr, Command cmds, Variable key, Variable value) {
		super(line);
		this.expr = expr;
		this.cmds = cmds;
		this.key = key;
		this.value = value;
	}
	
	public ForeachCommand(int line, Expr expr, Command cmds, Variable key) {
		super(line);
		this.expr = expr;
		this.cmds = cmds;
		this.key = key;
	}
	
	@Override
	public void execute() {
		
	}
}
