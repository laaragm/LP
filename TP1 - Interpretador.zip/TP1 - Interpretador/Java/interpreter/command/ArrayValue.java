package interpreter.command;

import java.util.Map;

import interpreter.expressions.Variable;

import java.util.HashMap;

public class ArrayValue extends CompositeValue<Map<String, Value<?>>> {

	private Map<String,Value<?>> value;

	public ArrayValue(Map<String, Value<?>> value) {
		this.value = new HashMap<String,Value<?>>(value);
	}

	public Map<String,Value<?>> value() {
		/*
        if (this.value instanceof StringValue) {
        	return ((StringValue)this.value).value();
        }
        else if (this.value instanceof IntegerValue) {
        	return this.value.value();
        }
        else if (this.value instanceof ArrayValue) {
        	System.err.println("Invalid type");
            System.exit(0); 
        }
        
		return value; */
		return null;
	}
  
}

