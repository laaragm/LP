package interpreter.command;

import interpreter.expressions.BoolExpr;

public class WhileCommand extends Command {

	protected BoolExpr cond;
	protected Command cmds;
	
	public WhileCommand(int line, BoolExpr cond, Command cmds) {
		super(line);
		this.cond = cond;
		this.cmds = cmds;
	}
	
	@Override
	public void execute() {
		
	}
	
	
}
