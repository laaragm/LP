package interpreter.command;

import interpreter.expressions.Expr;
import interpreter.expressions.IntegerExpression;

public class EchoCommand extends Command {
	
	protected Expr expr;

	public EchoCommand(int line, Expr expr) {
		super(line);
		this.expr = expr;
	}

	@Override
	public void execute() {
		System.out.println(this.expr.expr());
	}
	
}
