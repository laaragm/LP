package interpreter.command;

import java.util.List;

public class BlocksCommand extends Command {
	
	protected List<Command> cmds;

	public BlocksCommand(int line) {
		super(line);
	}
		
	public void addCommand(Command cmd){
        this.cmds.add(cmd);
    }

	@Override
	public void execute() {
		for(Command c: this.cmds){
            c.execute();
        }
	}
	
}
