package interpreter.command;

public enum AssignOp {
	NoAssignOp,
	StdAssignOp,
	AddAssignOp,
	SubAssignOp,
	ConcatAssignOp,
	MulAssignOp,
	DivAssignOp,
	ModAssignOp
}
