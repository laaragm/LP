package interpreter.command;

public abstract class CompositeValue<T> extends Value<T> {

	public CompositeValue() {
		  
	}

	public abstract T value();

}
