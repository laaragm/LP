package interpreter.command;

import interpreter.expressions.Expr;

public class AssignCmd extends Command {

	protected Expr left;
	protected AssignOp op;
	protected Expr right;
	
	public AssignCmd(int line, Expr left, AssignOp op, Expr right) {
		super(line);
		this.left = left;
		this.op = op;
		this.right = right;
	}
	
	public AssignCmd(int line, Expr left, AssignOp op) {
		super(line);
		this.left = left;
		this.op = op;
	}
	
	@Override
	public void execute() {
		
	}

}
